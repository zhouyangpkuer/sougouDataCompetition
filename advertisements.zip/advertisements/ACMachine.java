import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import java.io.BufferedReader;  
import java.io.FileInputStream;  
import java.io.InputStreamReader;  
import java.io.FileOutputStream; 
import java.io.OutputStreamWriter;
import java.util.*;
import org.ahocorasick.trie.*;

public class ACMachine
{
	public static void main(String []argc)
	{
		TrieConfig tc = new TrieConfig();
		Trie T = new Trie(tc, false);
		
		try
        {
        	String SourceFileName1 = "adver_word_f_filted";
        	String SourceFileName2 = "experiment_content";
        	
            //String SourceFileName2 = "adver_content";

            //String DestFileName = "adver_content_weight";

            String DestFileName = "experiment_content_weight";

            StringBuffer FileContent = new StringBuffer();

            FileInputStream fis1 = new FileInputStream(SourceFileName1); 
            InputStreamReader isr1 = new InputStreamReader(fis1, "UTF-8"); 
            BufferedReader br1 = new BufferedReader(isr1); 

            FileInputStream fis2 = new FileInputStream(SourceFileName2); 
            InputStreamReader isr2 = new InputStreamReader(fis2, "UTF-8"); 
            BufferedReader br2 = new BufferedReader(isr2); 

            FileOutputStream fos = new FileOutputStream(DestFileName); 
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8"); 
        
            String line = null;
            HashMap<String, Integer> word_f = new HashMap<String, Integer>();
            //ArrayList<String> vec = new ArrayList<String>();

            StringTokenizer st = null;
            String word;
            int f;
            int count = 0;

            while ((line = br1.readLine()) != null)
            { 
            	System.out.printf("success" + count + "!\n");
            	count++;

            	st = new StringTokenizer(line, " ");
            	word = st.nextToken();
            	f = Integer.parseInt(st.nextToken());

            	word_f.put(word, f);

            	T.addKeyword(word);
            }

            int weight = 0;
            ArrayList<Emit> list = null;

            count = 0;

            while((line = br2.readLine()) != null)
            {
            	weight = 0;
				list = (ArrayList<Emit>)T.parseText(line);
				for(Emit str : list)
				{
					weight += word_f.get(str.getKeyword());
					//FileContent.append(str.getKeyword() + " ");
				}
				System.out.printf("success" + count + " " + weight + "!\n");
            	count++;

				FileContent.append(weight + "\n");			    	
            }

            osw.write(FileContent.toString()); 
            osw.flush();
        }
        catch(Exception e)
        {  
            e.printStackTrace();  
        }

	}
}