import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import com.chenlb.mmseg4j.ComplexSeg;
import com.chenlb.mmseg4j.Dictionary;
import com.chenlb.mmseg4j.MMSeg;
import com.chenlb.mmseg4j.Seg;
import com.chenlb.mmseg4j.Word;

import java.io.BufferedReader;  
import java.io.FileInputStream;  
import java.io.InputStreamReader;  
import java.io.FileOutputStream; 
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Complex 
{
	protected Dictionary dic;
	
	public Complex() 
	{
		dic = Dictionary.getInstance();
	}

	protected Seg getSeg() 
	{
		return new ComplexSeg(dic);
	}
	
	public String segWords(Reader input, String wordSpilt) throws IOException
	{
		StringBuilder sb = new StringBuilder();
		Seg seg = getSeg();	//取得不同的分词具体算法
		MMSeg mmSeg = new MMSeg(input, seg);
		Word word = null;
		boolean first = true;
		while((word=mmSeg.next())!=null) {
			if(!first) {
				sb.append(wordSpilt);
			}
			String w = word.getString();
			sb.append(w);
			first = false;
			
		}
		return sb.toString();
	}
	
	public String segWords(String txt, String wordSpilt) throws IOException 
	{
		return segWords(new StringReader(txt), wordSpilt);
	}
	
	protected void run(String SourceFileName, String DestFileName, String NextLineSym) throws IOException 
	{
		try
        {
            StringBuffer FileContent = new StringBuffer();

            FileInputStream fis = new FileInputStream(SourceFileName); 
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8"); 
            BufferedReader br = new BufferedReader(isr); 

            FileOutputStream fos = new FileOutputStream(DestFileName); 
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8"); 
        
            String line = null;

            while ((line = br.readLine()) != null)
            { 
                FileContent.append(segWords(line, " ") + NextLineSym); 
                //System.out.println(segWords(line, " "));
            }   

            osw.write(FileContent.toString()); 
            osw.flush();
        }
        catch(Exception e)
        {  
            e.printStackTrace();  
        }
	}
	
	public static void main(String[] args) throws IOException 
	{	
		//new Complex().run("adver_content", "adver_word", " ");
		new Complex().run("experiment_content", "experiment_word", "\n");
	}

}
