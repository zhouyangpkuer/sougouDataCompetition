import java.io.BufferedReader;  
import java.io.FileInputStream;  
import java.io.InputStreamReader;  
import java.io.FileOutputStream; 
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;
class Content_separate
{
    public Content_separate(String SourceFileName, String DestFileName)
    {
        try
        {
            StringBuffer FileContent = new StringBuffer();

            FileInputStream fis = new FileInputStream(SourceFileName); 
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8"); 
            BufferedReader br = new BufferedReader(isr); 

            FileOutputStream fos = new FileOutputStream(DestFileName); 
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8"); 
        
            String line = null;
            StringTokenizer st = null;
            int count = 14;

            while ((line = br.readLine()) != null)
            { 
                st = new StringTokenizer(line, "\t");
                count = 14;
                while(count != 0)
                {
                    st.nextToken();
                    count--;
                }
                FileContent.append(st.nextToken() + "\n");  
            }   

            osw.write(FileContent.toString()); 
            osw.flush();
        }
        catch(Exception e)
        {  
            e.printStackTrace();  
        }

    }
}

public class Content_separate_test
{
    public static void main(String []args)
    {
        Content_separate cs = new Content_separate("advertisement", "adver_content");
        Content_separate _cs = new Content_separate("experiment", "experiment_content");   
    }
}