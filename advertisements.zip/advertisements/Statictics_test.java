import java.io.BufferedReader;  
import java.io.FileInputStream;  
import java.io.InputStreamReader;  
import java.io.FileOutputStream; 
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.StringTokenizer;
import java.util.Collections;  
import java.util.Comparator;  
import java.util.HashMap;  
import java.util.List;
import java.util.ArrayList;

class Statictics
{
	public HashMap<String, Integer> run(String SourceFileName) throws IOException 
	{
		HashMap<String, Integer> word_f = new HashMap<String, Integer>();
		try
        {

            FileInputStream fis = new FileInputStream(SourceFileName); 
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8"); 
            BufferedReader br = new BufferedReader(isr); 

            String line = null;
            StringTokenizer st = null;
            String temp = null;

            while ((line = br.readLine()) != null)
            { 
            	st = new StringTokenizer(line, " ");
            	while(st.hasMoreTokens())
            	{
            		temp = st.nextToken();

            		Integer oldvalue = word_f.get(temp);

            		if(oldvalue == null)
            		{
            			word_f.put(temp, 1);
            		}
            		else
            		{
            			word_f.put(temp, oldvalue + 1);
            		}
            	}
            }
        }
        catch(Exception e)
        {  
            e.printStackTrace();  
        }
        return word_f;
	}
}
class HashMap_sort
{
	public StringBuffer run(HashMap<String, Integer> word_f)throws IOException
	{
		List<String> v = new ArrayList<String>(word_f.keySet());  
    	Collections.sort(v, new Comparator<Object>()
    	{  
        	public int compare(Object arg0, Object arg1)  
       		{   
            	return word_f.get(arg1) - (word_f.get(arg0));  
        	}  
   		});
   		StringBuffer sort_res = new StringBuffer();  
    	for (String str : v) 
    	{  
     		sort_res.append(str + " " + word_f.get(str) + "\n");  
    	}
    	return sort_res;
  	}  
}
public class Statictics_test
{
	public static void main(String []args)
	{
		try
        {
			Statictics S = new Statictics();
			HashMap_sort Hs = new HashMap_sort();

			StringBuffer res = Hs.run(S.run("adver_word"));

			FileOutputStream fos = new FileOutputStream("adver_word_f"); 
       	 	OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8"); 
 
        	osw.write(res.toString()); 
        	osw.flush();
        }
        catch(Exception e)
        {  
            e.printStackTrace();  
        }
	}
}