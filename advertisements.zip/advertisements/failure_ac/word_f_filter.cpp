#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<cstring>
using namespace std;
int main()
{
    freopen("adver_word_f","r",stdin);
    freopen("adver_word_f_filted","w",stdout);
    char str[2000];
    int f, len;
	while(~scanf("%s%d", str, &f))
	{
		len = strlen(str);
		cerr << str << " ";
		if(f <= 3)
			continue;
		cerr << "!" << " ";
		if(len <= 3)
			continue;
		cerr << len << "!" << endl;
		printf("%s %d\n", str, f);	
	}
	return 0;	
}
