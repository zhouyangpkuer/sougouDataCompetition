import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import java.io.BufferedReader;  
import java.io.FileInputStream;  
import java.io.InputStreamReader;  
import java.io.FileOutputStream; 
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;
class cul_cc_num
{
	public int parse(String src)
	{
	    char[] t1 = null;
        t1 = src.toCharArray();
        int t0 = t1.length;
        int count = 0;
        for (int i = 0; i < t0; i++) 
        {
        	if (Character.toString(t1[i]).matches("[\\u4E00-\\u9FA5]+"))
        	{
            	count ++;
        	}
        }
        return count;
	}
}
public class keywordfilter
{
	public static void main(String []argc)
	{
		try
        {
        	String SourceFileName = "adver_word_f";
        	String DestFileName = "adver_word_f_filted";

            StringBuffer FileContent = new StringBuffer();

            FileInputStream fis = new FileInputStream(SourceFileName); 
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8"); 
            BufferedReader br = new BufferedReader(isr); 

            FileOutputStream fos = new FileOutputStream(DestFileName); 
            OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8"); 
        
        	cul_cc_num cc_parse = new cul_cc_num();

            String line = null;
            StringTokenizer st = null;
            String word;
            int f;

            while ((line = br.readLine()) != null)
            { 
            	st = new StringTokenizer(line, " ");
            	word = st.nextToken();
            	f = Integer.parseInt(st.nextToken());

            	if(f <= 3 || cc_parse.parse(word) <= 1)
            		continue;

                FileContent.append(word + " " + f + "\n"); 
                //System.out.println(segWords(line, " "));
            }   

            osw.write(FileContent.toString()); 
            osw.flush();
        }
        catch(Exception e)
        {  
            e.printStackTrace();  
        }
	}
}