import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import java.io.BufferedReader;  
import java.io.FileInputStream;  
import java.io.InputStreamReader;  
import java.io.FileOutputStream; 
import java.io.OutputStreamWriter;
import java.util.*;
import org.ahocorasick.trie.*;

public class test_ac
{
	public static void main(String []argc)
	{
        TrieConfig tc = new TrieConfig();
		Trie T = new Trie(tc, false);
		try
        {
            ArrayList<Emit> emits = null;

            T.addKeyword("我是");
            T.addKeyword("你好");
            T.addKeyword("大家好");
            T.addKeyword("集合");
            T.addKeyword("熟悉");
            T.addKeyword("数学");
        	emits = (ArrayList<Emit>)T.parseText("我是熟悉你么好吗，数学");
            /*T.addKeyword("hers");
            T.addKeyword("his");
            T.addKeyword("she");
            T.addKeyword("he");
            emits = (ArrayList<Emit>)T.parseText("ushers");*/
			for(Emit str : emits)
			{
                System.out.printf(str.getKeyword() + "\n");
			}
        }
        catch(Exception e)
        {  
            e.printStackTrace();  
        }

	}
}